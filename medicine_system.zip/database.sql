-- Fresh SQLite schema for Medicine Scanner.
-- The running API applies the same schema and preserves existing scanner data.

CREATE TABLE users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  username TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  account_status TEXT NOT NULL DEFAULT 'active' CHECK(account_status IN ('active','disabled')),
  created_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX users_username_unique ON users(LOWER(username));
CREATE UNIQUE INDEX users_email_unique ON users(LOWER(email));
CREATE INDEX users_account_status ON users(account_status);

CREATE TABLE scans(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t INTEGER,
  code TEXT,
  name TEXT,
  batch TEXT,
  expiry TEXT,
  status TEXT,
  demo INTEGER DEFAULT 0,
  device_ack TEXT NOT NULL DEFAULT 'NOT_CONFIRMED',
  led_action TEXT NOT NULL DEFAULT 'NOT_CONFIRMED',
  buzzer_action TEXT NOT NULL DEFAULT 'NOT_CONFIRMED',
  alert_message TEXT NOT NULL DEFAULT ''
);
CREATE TABLE medicines(
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  batch TEXT NOT NULL DEFAULT '',
  expiry TEXT NOT NULL
);

CREATE TABLE activity_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t INTEGER,
  actor TEXT,
  action TEXT,
  details TEXT
);
CREATE TABLE chat_messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t INTEGER,
  sid TEXT,
  phone TEXT,
  role TEXT,
  content TEXT
);
CREATE TABLE patient_profiles(
  pkey TEXT PRIMARY KEY,
  name TEXT,
  age TEXT,
  allergies TEXT,
  medicines TEXT
);
CREATE TABLE ai_feedback(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t INTEGER,
  sid TEXT,
  message TEXT,
  rating INTEGER
);
CREATE TABLE ai_knowledge(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT,
  answer TEXT,
  created_at INTEGER
);

CREATE TABLE auth_login_attempts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  identity_hash TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  attempted_at INTEGER NOT NULL
);
CREATE INDEX auth_login_attempts_window ON auth_login_attempts(identity_hash,ip_hash,attempted_at);
CREATE TABLE auth_remember_tokens(
  selector TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX auth_remember_tokens_user ON auth_remember_tokens(user_id,created_at);
CREATE TABLE password_reset_tokens(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX password_reset_tokens_user ON password_reset_tokens(user_id,expires_at);
CREATE TABLE password_reset_attempts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  identity_hash TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  requested_at INTEGER NOT NULL
);
CREATE INDEX password_reset_attempts_window ON password_reset_attempts(identity_hash,ip_hash,requested_at);

INSERT INTO medicines(code,name,batch,expiry) VALUES
  ('MED001','Paracetamol 500mg','P0012026','2028-12-31'),
  ('MED003','Ibuprofen 400mg','I2209','2026-03-01');
